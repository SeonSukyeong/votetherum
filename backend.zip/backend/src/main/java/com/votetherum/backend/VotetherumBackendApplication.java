package com.votetherum.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VotetherumBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(VotetherumBackendApplication.class, args);
	}

}
