package com.votetherum.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VotetherumBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
